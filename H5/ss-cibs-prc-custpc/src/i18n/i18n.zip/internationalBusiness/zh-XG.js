
export default {
    //外币牌价
    FOREXLISTPRICE:{
        BANKNOTE:'外幣現鈔',
        TELEGRAPHIC_TRANSFER:'外幣電匯',
        TELEGRAPHIC_TRANSFER_RATES:'外幣電匯兌港幣牌價',
        BANKNOTE_RATES:'外幣現鈔兌港幣牌價',
        THE_FOLLOWING_INFORMATION_IS_FOR_REFERENCE_ONLY:'以下資料僅供參考。',
        LAST_UPDATE_TIMES:'最後更新時間:',
        CURRENCY:'外幣',
        CUSTOMER_BUYS:'銀行買入',
        CUSTOMER_SELLS:'銀行賣出',
        CUSTOMER_BUYSONE:'客戶買入',
        CUSTOMER_SELLSONE:'客戶買入',
        FILL_IN_THE_PURCHASE_INFORMATION:'填寫購買資料',
        CONFIRM_TRANSACTION_INFORMATION:'確認交易資料',
        TRANSACTION_SUCCESS:"提交結果"

    },

    //货币兑换
    REMITTANCECONFIRM:{
        RESET:'重置',
        CURRENCY:'貨幣',
        ACCOUNT:'賬戶',
        AMOUNT:'金額',
        ACCOUNT_NAME:'賬戶名稱',
        AVAILABLE_BALANCE:'可用結餘',
        YOU_HAVE_SELECTED_TO_FIX_THIS_AMOUNT:'你已選擇以此金額為准。',
        FOREGIN_CURRENCY_QUOTATION_INQUIRY:'外幣牌價查詢',
        SERVICE_HOURS:'服務時間',
        PLEASE_ENTER_THE_AMOUNT:'請輸入金額',
        PLEASE_ENTER_THE_CURRENCY:'請選擇轉賬銀碼之貨幣',
        INVOIVED_ACCOUNTS:'外幣兌換其中一個賬戶必須為港幣儲蓄或往來賬戶',
        TIME_TIPS: [
            '1.上午8時30分至下午6時（星期一至五）及上午8時30分至下午1時（星期六），星期日及公眾假期除外；',
            '2.服務時間外遞交之指示將不會被接受；',
            '3.外幣兌換的交易指示將即時處理。'

        ],
        RISK_DISCLOSURE: '風險披露聲明:',
        RISK_TIPS: '外币投资受汇率波动而产生获利机会及亏损风险。客户如将外币兑换成为港币或其他外币时,可能受外币汇率的波动而获利或蒙受亏损.因此,你应慎重考虑该项目是否适合你的财务状况以及投资目标。人民币目前并未能自由兑换,而香港各银行进行人民币兑换均受中国/或香港有关规管当局或有关机构不时厘定之规则、指引、规定及条款所规限',
        NOTE: '註：',
        TIPS: [
            '1.外幣兌換只適用於您名下賬戶間之交易，而其中一個轉賬賬戶必須為港幣儲蓄或往來賬戶。',
            '2.人民幣兌換方面，支賬及入賬戶需為客戶名下的創興銀行之多種貨幣儲蓄賬戶與港幣儲蓄或往來賬戶。此兌換服務只限於已登記網上銀行服務之個人客戶。',
            '3.外幣兌換每日最高限額（每賬戶）港幣3,000,000元，每筆交易最高限額為港幣1,000,000元，最低限額為港幣500元。',
            '4.當交易指示已被執行後，畫面會顯示一個參考編號，以便您於日後作出查核。如畫面沒有顯示參考編號或您不確定有關交易是否已執行，請於重新進行交易前先查詢相關賬戶之結餘，以避免重複交易。',

        ],
        CURRENCY_EXCHANGE:'貨幣兌換',
        FOR_REFERENCE_ONLY:'僅供參考',
        CHANGED:'當匯率改變,此金額將于確認版面自動更新',
        EXCHANGE_RATE:'匯率',
        AMOUNT_UPDATED:'金額已更新',
        TIPSONE:'溫馨提示',
        NOTEONE:'註：在確認交易前匯率有所變動,兌換金額將會更新,現已刷新最新的兌換金額',
        ONLINE_BANKING_SERIAL_NUMBER:'網銀流水號',
        PROGRESS:'請至授權中心查看授權進度',
        REASON_FOR_FAILURE:'失敗原因',
        TRANSACTION_RESULT:'交易結果',
        SUBMISSION_Failure:'提交失敗'
    },

    //查询服务
    INTERESTRATEQUERY:{
        EXCHANGE_RATE_QUERY:'儲蓄存款利率',
        INTEREST_RATE_QUERY:'定期存款利率',
        DEPOSIT_AMOUNT:'存款額',
        DEPOSIT_TENOR:'存款期',
        BANKNOTE:'外幣現鈔兌港元牌價',
        TELEGRAPHIC_TRANSFER:'外幣現匯兌港元牌價',
        ONLINE_BANKING_SERIAL_NUMBER:'網銀流水號',
        BANK_BRANCH_INFORMATION:'銀行分行咨訊',
        CUSTOMER_SERVICES_HOTLINE:'客戶熱線',
        BRANCH_NAME:'分行名稱',
        ADDRESS:'地址',
        MOBILE:'電話',
        SERVICE_TIME:'服務時間:',
        SERVICE_TIME2:'星期一至五：9:00~18:00  星期六：9:00~13:00',
        OBJECTIVE:'我們的進步,源自每一次您與我們的交流',
        APP_DOWNLOAD:'APP下載',
        SCAN:'掃碼下載創興企業銀行APP',
        CHECK:"查看",
        TRANSACTION_SUCCESSFUL:'交易成功',
        PARTIALLY_SUCCESSFUL:'部份交易成功',
        PARTIALLY_FAILED:'交易失敗',
        PROCESSING:'銀行處理中',
        ONE_DAY:'1天',
        SEVEN_DAY:'7天',
        FOUR_DAY:'14天',
        ONE_MONTH:'1個月',
        TWO_MONTH:'2個月',
        THREE_MONTH:'3個月',
        SIX_MONTH:'6個月',
        NINE_MONTH:'9個月',
        EVE_MONTH:'12個月',
        TWO_tHERR:'24個月',
        TO:'至',
        ABOVE:'或以上',
        INTEREST_RATE:'年利率 (% p.a.)'
  
      }
}