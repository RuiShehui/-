/*
 * @Author: your name
 * @Date: 2022-07-04 19:47:55
 * @LastEditTime: 2022-07-05 10:21:00
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \ss-cibs-prc-custpc\src\i18n\user\zh.js
 */
export default {
  USER_COMMON:{
    CHANGE_PASSWORD:'修改密码',
    LONGIN_NEW_PASSWORD:'现时密码',
    PLACEHOLDER_LOGIN:'请输入现时密码',
    NEW_PASSWORD:'新密码',
    PLACEHOLDER_NEW:'请输入新密码',
    CONFIRM_NEW_PASSWORD:'再输入新密码',
    PLACEHOLDER_CONFIRM:'请再次输入新密码',
    RESET:'重置',
    NEXT:'提交',
    DIFF_PASSWORD:'两次输入密码不一致',
    INPUT_PASSWORD:'请输入密码',
    LESS_PASSWORD:'密码长度不能小于8位',
    MORE_PASSWORD:'密码长度不能大于12位',
    SAME_PASSWORD:'新密码不能与原密码相同',
    ERROR_PASSWORD:'请输入8-12位数字、字母中的至少两种组合',
    NULL_PASSWORD:'密码不能为空',
    NULL_NEWPASSWORD:'新密码不能为空',
    CONFIRM_PASSWORD:'确认密码不能为空',
    UDATE_SUCCESS:'修改成功',
    UPDATE_PASSWORD:'修改密码',
    FINIFISH:'完成',
    USER_NAME:'用户名',
    USER_CODE:'客户编号',
    UPDATE_USERNAME:'修改用户名',
    INPUT_USERNAME:'请输入用户名',
    TIPS:'温馨提示',
    TIPS_ONE:'1.网银用户名为8-12位的字符（必须同时包含字母、数字）',
    TIPS_TWO:'2.网银用户名修改后，企业手机银行用户名同步修改',
    NULL_USERNAME:'用户名不能为空',
    CONFIRM_USERNAME:'确定修改为以下用户名?',
    CANCLE:'取消',
    CONFIRM:'确定',
    UPDATE_USERNAME_SUCCESS:'用户名修改成功',
    UPDATE_NSERNAME_FAIL:'用户名修改失败',
    LESS_USERNAME:'用户名长度不能小于8位',
    MORE_USERNAME:'用户名长度不能大于12位' ,
    ERROR_USERNAME:'网银用户名为8-12为字符（必须包含字母、数字）'

  },
  MOBILE_TOKEN:{
    MOBILE_TOKEN_REGISTRATION:'登记流动保安认证',
    REGISTRATION_PROCESS:'部分流动保安认证2的登记过程将于创兴企业流动理财应用程式中进行。在创兴企业流动理财应用程式中进行登记前，请依下列指示作准备：',
    MOBILE_DEVICE_READY:'1.准备您的流动装置。(此服务只适用于指定装置型号。详情请参阅常见问题页面。)',
    DOWNLOAD_OR_UPDATE:'2.下载或更新创兴企业流动理财应用程式。',
    CORPORATE_MOBILE_BANKING_APP:'3.开启创兴企业流动理财应用程式，于左上角选单中按' ,
    SCAN_THE_QR_CODE:'按此页面的「确定」按钮后，页面会展示一个二维码。请用创兴企业流动理财应用程式中的「二维码扫描器」扫描企业网上银行上的二维码，并依创兴企业流动理财应用程式的指示完成登记。',
    COLLECT_YOUR_FACE:'1、本行不会收集您的Face ID /指纹及编码。',
    ACTIVATED_ONLINE_HIGH_RISK:'2、流动保安认证只适用於已启动网上高风险交易设定的客户。如要启动网上高风险交易设定，请填妥「创兴企业网上银行服务-启动/更改/停用网上高风险交易设定及以短讯接收一次性密码」表格及亲身将表格交回任何创兴银行本港分行办理。',
    Refresh_QR_Code:'更新二维码',
    GENERATE_NEW:'请用流动应用程式中的「二维码扫描器」扫描企业网上银行上的二维码。如您未能于时限内扫描二维码，可按「更新二维码」按钮以获取新的二维码。',
    REGISTERED_MOBILE_DEVICE:'已登记流动装置',
    TERMINATION_OF_SERVICE:'终止服务',
    REGISTERED_DEVICE:'已登记装置',
    BRAND:'品牌',
    OS_VERSION:'操作系统版本',
    REGISTERED_SERVICE:'已登记服务',
    MOBILE_TOKEN_SERVICE:'流动保安认证服务',
    TERMINATION_SERVICES:'在终止服务前，请注意以下事项 ',
    REGISTERED_SERVICES:'1.在按「确定」按钮后，所有登记服务（例如 : 流动保安认证服务）均会被终止',
    HIGH_RISK_TRANSACTION:'2、在终止流动保安认证服务后，您将不能以流动保安认证进行网上高风险交易。',
    FINGERPRINT_AND_PIN:'3、本行不会收集您的Face ID /指纹及编码。',
    BEEN_TERMINATED:'您曾登记的服务已被终止'

}
}