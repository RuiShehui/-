/*
 * @Autor: 朱涛
 * @Date: 2021-11-04 15:28:13
 * @LastEditors: zhangcheng
 * @LastEditTime: 2022-07-04 14:40:11
 * @Description: 
 * @FilePath: \ss-cibs-prc-custpc\src\i18n\lang\en.js
 * @symbol_custom_string_obkorol: 可以输入预定版本的版权声明、个性签名、空行等
 */
import accountManagement from "../accountManagement/en.js";
import invest from "../invest/en.js";
import Logon from "../login/en.js"
import transferRemittance from "../transferRemittance/en.js";
import home from "../home/en.js"
import internationalBusiness from "../internationalBusiness/en.js";
import payService from "../payService/en.js";
import applyCheckBoock from "../applyCheckbook/en.js";
import userManagement from "../userManagement/en.js";
import user from "../user/en.js";
import fixed from "../fixed/en.js"
import bathTransfer from '../batch-transfer/en.js'
import authorizeCenter from '../authorizeCenter/en.js'
export default {
  ...accountManagement,
  ...invest,
  ...transferRemittance,
  ...Logon,
  ...home,
  ...internationalBusiness,
  ...payService,
  ...applyCheckBoock,
  ...userManagement,
  ...user,
  ...fixed,
  ...bathTransfer,
  ...authorizeCenter,
  lang: {
    simplify: "简体",
    traditional: "繁體",
    english: "English"
  },
  COMMON: {
    TISHI: "",
    DETERMINE: "",
    CANCEL: "Cancel",
    CONFIRM: "Confirm",
    SUBMIT: "Submit",
    NEXT_STEP: "Next step",
    PREVIOUS_STEP: "Prev step",
    EXIT: "",
    REMIND: "",
    SEARCH: "Search",
    RESET: "Reset",
    ADD: "Add",
    DETAIL: 'Detail',
    OPERATION: "Operation",
    UPLOAD: '',
    RESET_PASSWORD: "Reset password",
    DELETE: "Delete",
    UPDATE: "Update",
    PLEASE_SELECT: "Please select", // 请选择%{label}...
    PLEASE_SELECT_SOMETHING: "please select the %{select}",
    SERIAL_NUMBER: "No",
    BACK: "Back",
    UPLOAD_TYPE_ERROR: "",
    START_TIME: '',
    END_TIME: '',
    START_DATE: '',
    END_DATE: '',
    DATESPAN_TO: '',
    PLEASE_INPUT: 'Please input', // '请输入%{label}...'
    PLEASE_INPUT_SOMETHING: 'Please input the %{input}',
    SELECT_LANGS: '',
    PREPEAR_HANDLE: '',
    IS_HANDLED: '',
    QUERY_INTERVAL: "",
    EMAIL_CONTENT_INVALID: '',
    EMAIL_NOT_ALLOW_EMPTY: '',
    EMAIL_FORMAT_INVALID: '',
    STEPS_FILL_INFORMATION: "填写信息",
    STEPS_COMFIRM_INFORMATION: "确认信息",
    STEPS_RESULT_INFORMATION: "交易结果",
    INIT_DATA_SUCCESS: '',
    CHECK_FAIL: 'Validation failed',
    SOMETHING_SUCCESS: '',
    UPDATE_SUCCESS: "",
    ADD_SUCCESS: "",
    DELETE_SUCCESS: "",
    AGREE: 'Accepted',
    DISAGREE: 'Not Accepted',
    TOTAL: 'All',
    FINISH: 'Finish',
    YES: 'Yes',
    NO: 'No',
    /** 2022-03-01 */
    RECENT_7_DAYS: 'Last 7 days',
    RECENT_14_DAYS: 'Last 14 days',
    RECENT_30_DAYS: 'Last 30 days',
    WITHOUT_DATA: 'No Data',
    WEBBANK_FLOW_NO: 'Online banking serial number',
    TRANS_TYPE: "Transfer Type",
    ONE_MORE_TRANS: 'Transfer Again',
    /** 2022-03-01 */
    /** 2022-03-03 */
    SUBMIT_SUCCESS: 'Submitted successfully',
    SUBMIT_FAIL: 'Submission Failed',
    /** 2022-03-03 */
    /** 2022-03-22 */
    OTP_ERROR: 'The one-time SMS password is incorrect. If you enter the wrong or expired one-time SMS password for three consecutive times, the transaction will be automatically cancelled.',
    /** 2022-03-22 */
    /** 2022-03-31 */
    CONFIRM_DELETE_SOMETHING: 'Are you sure to remove %{content}',
    /** 2022-03-31 */
    /** 2022-05-25 */
    GET_VR_CODE: 'Get VerifyCode',
    /** 2022-05-25 */
  },
};