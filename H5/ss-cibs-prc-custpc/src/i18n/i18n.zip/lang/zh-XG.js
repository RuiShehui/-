/*
 * @Autor: 朱涛
 * @Date: 2021-11-04 15:28:13
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2022-06-20 14:48:30
 * @Description: 
 * @FilePath: \webbank-pc\src\i18n\lang\zh-XG.js
 * @symbol_custom_string_obkorol: 可以输入预定版本的版权声明、个性签名、空行等
 */
import accountManagement from "../accountManagement/zh-XG.js";
import invest from "../invest/zh-XG.js";
import logon from "../login/zh-XG.js"
import transferRemittance from "../transferRemittance/zh-XG.js";
import internationalBusiness from "../internationalBusiness/zh-XG.js";
import payService from "../payService/zh-XG.js";
import home from "../home/zh-XG.js";
import applyCheckBoock from "../applyCheckbook/zh-XG.js";
import userManagement from "../userManagement/zh-XG.js";
import user from "../user/zh-XG.js";
import fixed from '../fixed/zh-XG';
import bathTransfer from '../batch-transfer/zh-XG.js'
import authorizeCenter from '../authorizeCenter/zh-XG.js'
export default {
  ...accountManagement,
  ...invest,
  ...transferRemittance,
  ...logon,
  ...home,
  ...internationalBusiness,
  ...payService,
  ...applyCheckBoock,
  ...userManagement,
  ...user,
  ...fixed,
  ...bathTransfer,
  ...authorizeCenter,
  lang: {
    simplify: "简体",
    traditional: "繁體",
    english: "English"
  },
  // 公共部分
  COMMON: {
    TISHI: "提示",
    DETERMINE: "確定",
    CANCEL: "取消",
    CONFIRM: "確認",
    SUBMIT: "提交",
    PREVIOUS_STEP: "上一步",
    NEXT_STEP: '下一步',
    TRANSACTION_SUCCESS: '交易成功',
    EXIT: "退出",
    REMIND: "提醒",
    SEARCH: "查詢",
    RESET: "重置",
    ADD: "新增",
    DETAIL: '詳情',
    REEDIT: '重新編輯',
    REVOKE: '撤銷',
    COPY: '複製',
    OPERATION: "操作",
    UPLOAD: '上載',
    RESET_PASSWORD: "重置密碼",
    DELETE: "刪除",
    UPDATE: "修改",
    PLEASE_SELECT: "請選擇...", // 请选择%{label}...
    PLEASE_SELECT_SOMETHING: "請選擇%{select}",
    SERIAL_NUMBER: "序號",
    BACK: "返回",
    UPLOAD_TYPE_ERROR: "上載格式錯誤",
    START_TIME: '開始時間',
    END_TIME: '結束時間',
    START_DATE: '開始日期',
    END_DATE: '結束日期',
    DATESPAN_TO: '至',
    PLEASE_INPUT: '請輸入...', // '请输入%{label}...'
    PLEASE_INPUT_SOMETHING: '请輸入%{input}',
    SELECT_LANGS: '請選擇語言',
    PREPEAR_HANDLE: '待處理',
    IS_HANDLED: '已處理',
    QUERY_INTERVAL: "查詢區間不可超過90天！",
    EMAIL_CONTENT_INVALID: '郵箱內容有誤',
    EMAIL_NOT_ALLOW_EMPTY: '郵箱內容不得為空',
    EMAIL_FORMAT_INVALID: '郵箱格式錯誤',
    INIT_DATA_SUCCESS: '初始化數據成功',
    CHECK_FAIL: '校驗失敗',
    SOMETHING_SUCCESS: '%{op}成功',
    UPDATE_SUCCESS: "編輯成功！",
    ADD_SUCCESS: "新增成功！",
    DELETE_SUCCESS: "刪除成功！",
    TRADE_TYPE: '交易類型',
    TRADE_STATUS: '交易狀態',
    STEPS_FILL_INFORMATION: "填写信息",
    STEPS_COMFIRM_INFORMATION: "确认信息",
    STEPS_RESULT_INFORMATION: "交易结果",
    SUBMITTER: '提交人',
    SUBMIT_TIME: '提交時間',
    AUTHORIZATION_STATUS: '授權狀態',
    CREATE_TIME: '創建時間',
    MONEY: '金額',
    AGREE: '接受',
    DISAGREE: '不接受',
    TOTAL: '全部',
    FINISH: '完成',
    YES: '是',
    NO: '否',
    /** 2022-03-01 */
    RECENT_7_DAYS: '最近7日',
    RECENT_14_DAYS: '最近14日',
    RECENT_30_DAYS: '最近30日',
    WITHOUT_DATA: '暫無數據',
    /** 2022-03-01 */
    /** 2022-03-03 */
    SUBMIT_SUCCESS: '提交成功',
    SUBMIT_FAIL: '提交失敗',
    /** 2022-03-03 */
    /** 2022-03-22 */
    OTP_ERROR: '一次性短訊密碼不正確。若連續三次輸入錯誤或逾時的一次性短訊密碼，該筆交易將自動取消。',
    /** 2022-03-22 */
    /** 2022-03-31 */
    CONFIRM_DELETE_SOMETHING: '確認是否刪除%{content}',
    /** 2022-03-31 */
    /** 2022-05-25 */
    GET_VR_CODE: '獲取驗證碼',
    /** 2022-05-25 */
  },
};