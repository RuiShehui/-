/*
 * @Author: your name
 * @Date: 2022-03-23 18:17:53
 * @LastEditTime: 2022-07-04 09:35:21
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \ss-cibs-prc-custpc\src\i18n\fixed\en.js
 */
export default {
  // 定期存款
  FIXED_DEPOSIT_OVERVIEW: {
    ACCOUNT_NUMBER: "Account Number",
    ACCOUNT_NAME: "Account Name",
    ACCOUNT_TYPE: "Account Type",
    CURRENT_BALANCE: "Account Balance",
    STATUS: "status",
    TOTAL_FIXED: "定期存款总值（港币等值）",
    TIPS: "TIPS",
    No_INTEREST: "1、No interest will be paid on the fixed deposit that is uplifted before maturity and the relevant premature uplifting fees will be charged. ",
    MATURITY_DATE: "2、On the maturity date of the time deposit or the date of early withdrawal, there may be a delay in the update of the deposit information. Please check on the next Business day",
    INTEREST_RATE: "3、Interest rate and renewal information will be provided on the next business day",
    LAST_UPDATE_TIME: 'Last Update Time',
    DEPOSIT_NUMBER: 'Deposit Number',
    VALUE_DATE: 'Value Date',
    MATURIT: 'Maturity Date',
    MATURITY_INSTRUCTION: 'Maturity Instruction',
    RENEW_PRINCIPAL: 'Renew principal and interest ',
    RENEW_PRINCIPALS: 'Renew principal and transfer interest to the designated account',
    TRANSFER_PRINCIPAL: 'Transfer principal and interest to the designated account',
    DEPOSIT_AMOUNT: 'Deposit Amount',
    INTEREST_RATES: 'Interest Rate',
    DEPOSIT_TENOR: 'Deposit Tenor',
    AMEND_MATURITY_INSTRUCTION: 'Amend Maturity Instruction',
    EXPECTED_INTEREST: 'Expected Interest',
    EXPECTED_PRINCIPAL: 'Expected Principal and Interest',
    DESIGNATED_ACCOUNT: 'Designated Account',
    REMARKS: 'Remarks',
    NEXT_DEPOSIT_TENOR: 'Next Deposit Tenor',
    FIXED_DEPOSIT_ACCOUNT: 'Fixed Deposit Account'
  },
  OPEN_FIXED: {
    PAYMENT_ACCOUNT: 'Payment Account',
    RATES_ENQUIRY: 'Rates Enquiry',
    INTEREST_CALCULATOR: 'Interest Calculator',
    AVAILABLE_BALANCE: 'Available Balance',
    SELECT_FIXED_TERM: 'Select by Fixed Term',
    SELECT_MATURITY_DATE: 'Select by Maturity Date',
    RATE: 'Rata',
    FIXED_DEPOSIT_PLACEMENT:'Fixed Deposit Placement',
    SERVICE_HOURS: '1.The service hours of Fixed Deposit Placement are from 9:00 am to 7:30 pm (Monday to Friday) and from 9:00 am to 4:00 pm (Saturday),  excluding Sunday and Public holidays. Any instructions submitted after service hours will not be accepted.',
    NO_INTEREST: '2.No interest will be paid on the fixed deposit that is uplifted before maturity and the relevant premature uplifting fees will be charged',
    DEPOSITS: '3. Deposits in the Fixed Deposit Account are qualified for protection under the Deposit Protection Scheme in Hong Kong. However, a fixed deposit with a tenor exceeding 5 years is NOT protected under the Scheme.'
  },
  APPOINTMENT_NUMBER:{
    APPOINTMENT_NUMBER:'The Appointment Number is incorrect. Please enter again',
    VALIDITY_PERIOD:'Appointment Number validity period:',
    NOT_YET:'It’s not yet the deposit date.' ,
    APPOINTMENT_NUMBER_EXPIRED:'The Appointment Number has expired. Please contact your Relationship Manager.',
    FIXED_TERM:'Fixed Term',
    MATURITY_DATE:'Maturity Date',
    APPOINTMENT_NUMBERS:'Appointment Number'
  }
} 