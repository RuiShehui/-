/*
 * @Author: your name
 * @Date: 2022-03-23 18:17:53
 * @LastEditTime: 2022-07-04 09:34:51
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \ss-cibs-prc-custpc\src\i18n\fixed\zh-XG.js
 */
export default {
  // 定期存款
  FIXED_DEPOSIT_OVERVIEW: {
    ACCOUNT_NUMBER: "賬戶號碼",
    ACCOUNT_NAME: "账戶名稱",
    ACCOUNT_TYPE: "賬戶類別",
    CURRENT_BALANCE: "賬戶結餘",
    STATUS: "狀態",
    TOTAL_FIXED: "定期存款总值（港币等值）",
    TIPS: "溫馨提示", 
    No_INTEREST: "1. 未到期前提取定期存款將不獲支付利息並須繳付到期前提款費用。",
    MATURITY_DATE: "2. 定期存款到期日或提前支取日當日，該存款資訊之更新可能有所延遲，請於下一個工作天查看。",
    INTEREST_RATE: "3. 利率及續存資訊將於下一個工作天提供。",
    LAST_UPDATE_TIME: '最後更新時間',
    DEPOSIT_NUMBER: '存款編號',
    VALUE_DATE: '起息日',
    MATURIT: '到期日',
    MATURITY_INSTRUCTION: '到期指示',
    RENEW_PRINCIPAL: '本息自動續存',
    RENEW_PRINCIPALS: '本金自動續存，利息轉入指定賬戶',
    TRANSFER_PRINCIPAL: '本息轉入指定賬戶',
    DEPOSIT_AMOUNT: '存款額',
    INTEREST_RATES: '年利率',
    DEPOSIT_TENOR: '存款期',
    AMEND_MATURITY_INSTRUCTION: '更改到期指示',
    EXPECTED_INTEREST: '預計可得利息',
    EXPECTED_PRINCIPAL: '預計可得本息',
    DESIGNATED_ACCOUNT: '指定賬戶',
    REMARKS: '備註',
    NEXT_DEPOSIT_TENOR: '下次存款期',
    FIXED_DEPOSIT_ACCOUNT:'定期存款賬戶'
  },
  OPEN_FIXED:{
    PAYMENT_ACCOUNT:'付款賬戶',
    RATES_ENQUIRY:'查詢利率',
    INTEREST_CALCULATOR:'利息計算器',
    AVAILABLE_BALANCE:'可用結餘',
    SELECT_FIXED_TERM:'按固定存期選擇',
    SELECT_MATURITY_DATE:'按到期日選擇',
    RATE:'利率',
    FIXED_DEPOSIT_PLACEMENT:'開立定期存款',
    SERVICE_HOURS:'1.開立定期存款之服務時間為上午9時至下午7時30分（星期一至五）及上午9時至下午4時（星期六），星期日及公眾假期除外。服務時間外遞交之指示將不會被接受',
    NO_INTEREST:'2.未到期前提取定期存款將不獲支付利息並須繳付到期前提款費用',
    DEPOSITS:'3. 定期存款賬戶內的存款是符合香港存款保障計劃保障資格的存款，但年期超過五年的定期存款將不受該計劃保障'
  },
  APPOINTMENT_NUMBER:{
    APPOINTMENT_NUMBER:'預約編號不正確，請重新輸入',
    VALIDITY_PERIOD:'預約編號有效期：',
    NOT_YET:'還未到約定存款日期' ,
    APPOINTMENT_NUMBER_EXPIRED:'該預約編號已過有效期，請聯絡您的客戶經理。',
    FIXED_TERM:'固定存期',
    MATURITY_DATE:'自定义存期',
    APPOINTMENT_NUMBERS:'預約編號'
  }
} 