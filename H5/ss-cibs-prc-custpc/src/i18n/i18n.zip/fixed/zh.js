/*
 * @Author: your name
 * @Date: 2022-01-19 10:16:40
 * @LastEditTime: 2022-07-05 12:49:54
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \ss-cibs-prc-custpc\src\i18n\fixed\zh.js
 */
export default {
  // 定期存款
  FIXED_DEPOSIT_OVERVIEW: {
    ACCOUNT_NUMBER: "账户号码",
    ACCOUNT_NAME: "账户名称",
    ACCOUNT_TYPE: "账户类别",
    CURRENT_BALANCE: "账户结余",
    STATUS: "状态",
    TOTAL_FIXED: "定期存款总值（港币等值）",
    TIPS: "温馨提示",
    No_INTEREST: "1、未到期前提取定期存款将不获支付利息并须缴付到期前提款费用",
    MATURITY_DATE: "2、定期存款到期日或提前支取日当日，该存款信息更新可能存在延迟，请于下一个工作天查看",
    INTEREST_RATE: "3、利率及续存资讯将于下一个工作天提供",
    LAST_UPDATE_TIME: '最后更新时间',
    DEPOSIT_NUMBER: '存款编号',
    VALUE_DATE: '起息日',
    MATURIT: '到期日',
    DEPOSIT_AMOUNT: '存款额',
    INTEREST_RATES: '年利率',
    DEPOSIT_TENOR: '存款期',
    AMEND_MATURITY_INSTRUCTION: '更改到期指示',
    MATURITY_INSTRUCTION: '到期指示',
    RENEW_PRINCIPAL: '本息自动续存',
    RENEW_PRINCIPALS: '本金自动续存，利息转入指定账户',
    TRANSFER_PRINCIPAL: '本息转入指定账户',
    EXPECTED_INTEREST: '预计可得利息',
    EXPECTED_PRINCIPAL: '预计可得本息',
    DESIGNATED_ACCOUNT: '指定账户',
    REMARKS: '备注',
    NEXT_DEPOSIT_TENOR: '下次存款期',
    FIXED_DEPOSIT_ACCOUNT: '定期存款账户',
    ONE_WEEK: '1星期',
    TWO_WEEK: '2星期',
    ONE_MONTHS: '1个月',
    TWO_MONTHS: '2个月',
    THREE_MONTHS: '3个月',
    SIX_MONTHS: '6个月',
    NINE_MONTHS: '9个月',
    TWELEVE_MONTHS: '12个月',
    TWENTY_MONTHS: '24个月'
  },
  OPEN_FIXED: {
    BOOK_RATE: '预约利率',
    ANY_FIXED_DEPOSIT: '您并未持有本行定期存款账户，请前往本行分行开立定期存款账户',
    PAYMENT_ACCOUNT: '付款账户',
    RATES_ENQUIRY: '查询利率',
    INTEREST_CALCULATOR: '利息计算器',
    AVAILABLE_BALANCE: '可用结余',
    SELECT_FIXED_TERM: '按固定存期选择',
    SELECT_MATURITY_DATE: '按到期日选择',
    RATE: '利率',
    FIXED_DEPOSIT_PLACEMENT: '开立定期存款',
    UPLIFTING_FEES: '1.未到期前提取定期存款将不获支付利息并须缴付到期前提款费用',
    SERVICE_HOURS: '2.开立定期存款之服务时间为上午9时至下午7时30分（星期一至五）及上午9时至下午4时（星期六），星期日及公众假期除外。服务时间外递交之指示将不会被接受。',
    NO_INTEREST: '3.未到期前提取定期存款将不获支付利息并须缴付到期前提款费用。',
    DEPOSITS: '4. 定期存款账户内的存款是符合香港存款保障计划保障资格的存款，但年期超过五年的定期存款将不受该计划保障。',
    SELECT_FIXED_DEPOSIT_ACCOUNT:'请选择定期存款账户',
    SELECT_PAYMENT_ACCOUNT:'请选择付款账户',
    ENTER_DEPOSIT_AMOUNT:'请输入存款金额',
    LESS_THAN:'存款额不能低于',
    CONTAINS_INVALID_CHARACTERS:'存款额含有不认可字符',
    MORE_THAN:'存款额不能超过2个小数位'
  },
  APPOINTMENT_NUMBER: {
    APPOINTMENT_NUMBER: '预约编号不正确，请重新输入',
    VALIDITY_PERIOD: '预约编号有效期',
    NOT_YET: '还未到约定存款日期',
    APPOINTMENT_NUMBER_EXPIRED: '该预约编号已过有效期，请联络您的客户经理',
    FIXED_TERM: '固定存期',
    MATURITY_DATE: '自定义存期',
    APPOINTMENT_NUMBERS: '预约编号'
  }
} 