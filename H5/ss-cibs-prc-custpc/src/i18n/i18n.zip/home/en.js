/*
 * @Author: your name
 * @Date: 2022-02-11 14:41:17
 * @LastEditTime: 2022-07-05 09:59:53
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \ss-cibs-prc-custpc\src\i18n\home\en.js
 */
export default {
    //首页
    HOME:{
        WELCOME_BACK:"Hello and welcome back",
        SUCCESSFUL_LOGON:"Last Successful Logon",
        MY_SETTING:"setting",
        SHORTCUT_FUNCTION:"Shortcut function",
        MY_SETTINGS:"setting",
        ASSET_VIEW:"Asset view(HKD)",
        RECENT_TRANSFER:"Recent transfer",
        MORE:"More",
        UPCOMING_TASKS:"Upcoming Tasks",
        DRAFT_TRANSACTION:"Draft transaction",
        MESSAGE_NOTIFICATION:"message notification",
        INVESTMENT:"1.'Investment' includes the balance of Investment Account and Securities Custodian Account .",
        STOCK_ACCOUNT:"2.The Securities Custodian Account balance is the market value on T-1",
        PASSWORD_IMMEDIATELY:'您的登入密码已长时间未修改，为了保障证您的账户安全，请立即修改密码。',
        CHANGE_NOW:'立即修改',
        REMIND_ME:'30天后提醒我',
        CORPORATE_INTERNET_BANKING:'您确定退出企业网上银行',
        LOG_OFF_NOW:'立即退出',
        AUTOMATICALLY_LOGGED_OFF:'您已长时间未操作企业网银系统，为保障用户安全，您将于30秒后自动退出。',
        LOGOUT_SUCCESSFUL:'成功退出'
    },

    // 公告
    NOTICE: {
        ANNOUNCEMENT_TITLE: 'Announcement title',
        RELEASE_DATE: 'release date',
        SERIAL_NUMBER: 'Serial number',
        NUMBERING: 'Numbering',
        TITLE: "title",
        RELEASE_TIME: "release time",
        OPERATE: 'operate',
        RESET: 'reset',
        DETAILS: 'Details',
        ENQUIRY: 'enquiry',
        PLEASE_ENTER: 'Please enter the title of the announcement',
        ANNOUNCEMENT_DETAILS: 'Announcement details',
        GO_TO_CHECK:'Go to Check'
    },

     // 最近转账
     TRANSCTIONS:{
        RECENT_TRANSFER:'Recent Transfer',
        MORE:'More',
        TOTAL_OF_RECORDS:'Total number of records'
    },

    // 待办事项
    Tasks:{
        UPCOMING_TASKS:'Upcoming Tasks',
        NUMBER:'Number',
        REFERENCE_NUMBER:'Reference Number',
        TRANSACTION_TYPE:'Transaction Type',
        PRESENTOR:'Presentor',
        SUBMISSION_TIME:'Submission Time'
    },
   
    // 拟订交易
    DRAFT_TRANSACTION:{
        UPLOAD_METHOD:'Upload Method',
        Temporary_Storage_Time:'Temporary Storage Time',
        MANUAL_INPUT:'Manual Input',
        FILE_UPLOAD:'File Upload'
    },
    
    NOTIFICATION:{
        REMINDER_NOTIFICATION:'Reminder Notification',
        NOTIFICATION:'Notification',
        TIME_OF_RECEIPT:'Time of Receipt',
        ALL:'All',
        UNREAD:'Unread',
        Clear_Unread:'Clear Unread'
    },


    // 流动保安
    MOBILE_TOKEN:{
        MOBILE_TOKEN_REGISTRATION:'登记流动保安认证',
        REGISTRATION_PROCESS:'部分流动保安认证2的登记过程将于创兴企业流动理财应用程式中进行。在创兴企业流动理财应用程式中进行登记前，请依下列指示作准备：',
        MOBILE_DEVICE_READY:'1.准备您的流动装置。(此服务只适用于指定装置型号。详情请参阅常见问题页面。)',
        DOWNLOAD_OR_UPDATE:'2.下载或更新创兴企业流动理财应用程式。',
        CORPORATE_MOBILE_BANKING_APP:'开启创兴企业流动理财应用程式，于左上角选单中按' 
    }

}