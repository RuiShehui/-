/*
 * @Author: your name
 * @Date: 2022-02-11 14:41:17
 * @LastEditTime: 2022-07-05 11:20:22
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \ss-cibs-prc-custpc\src\i18n\home\zh.js
 */
export default {
    //首页
    HOME:{
        WELCOME_BACK:"您好！欢迎回来！",
        SUCCESSFUL_LOGON:"最近一次成功登入",
        MY_SETTING:"个人设定",
        SHORTCUT_FUNCTION:"快捷选单",
        MY_SETTINGS:"设置",
        ASSET_VIEW:"资产视图(港币)",
        RECENT_TRANSFER:"最近转账",
        TOTAL_ASSETS:'资产总额（港元）',
        CASA_DEPOSIT:'CASA存款',
        DEPOSIT:'定期存款',
        INVSET:'投资',
        SAVINGS_DEPOSIT:'往来/储蓄存款',
        MORE:"更多",
        UPCOMING_TASKS:"待办事项",
        DRAFT_TRANSACTION:"拟订交易",
        MESSAGE_NOTIFICATION:"提示通知",
        ANNOUNCEMENT_NOTICE:'公告通知',
        INVESTMENT:"1..“投资”包含投资账户和股票托管账户结余",
        STOCK_ACCOUNT:"2.股票托管账户结余为T-1日市值",
        PASSWORD_IMMEDIATELY:'您的登入密码已长时间未修改，为了保障证您的账户安全，请立即修改密码。',
        CHANGE_NOW:'立即修改',
        REMIND_ME:'30天后提醒我',
        CORPORATE_INTERNET_BANKING:'您确定退出企业网上银行',
        LOG_OFF_NOW:'立即退出',
        AUTOMATICALLY_LOGGED_OFF:'您已长时间未操作企业网银系统，为保障用户安全，您将于30秒后自动退出。',
        LOGOUT_SUCCESSFUL:'成功退出',
        TERMS_OF_SERVICE:'服务章则',
        PRIVACY_POLICY_ATEMENT:'隐私政策声明',
        INFORMATION_COLLECTION_STATEMENT:'收集个人资料声明',
        IMPORTANT_STATEMENT:'重要声明',
        RIGHTS_RESERVED:'©2022 创兴银行有限公司。版权所有',
        ELECTRONIC_BILLING:'电子账单章则'
    },

    // 公告
    NOTICE: {
        ANNOUNCEMENT_TITLE: '公告标题',
        RELEASE_DATE: '发布日期',
        SERIAL_NUMBER: '序号',
        NUMBERING: '编号',
        TITLE: "标题",
        RELEASE_TIME: "发布时间",
        OPERATE: '操作',
        RESET: '重置',
        DETAILS: '详情',
        ENQUIRY: '查询',
        PLEASE_ENTER: '请输入公告标题',
        ANNOUNCEMENT_DETAILS:'公告详情',
        VIEW_APPROVAL_RESULTS:'查看审批结果',
        GO_TO_CHECK:'去查看'
    },

    // 最近转账
    TRANSCTIONS:{
        RECENT_TRANSFER:'最近转账',
        MORE:'更多',
        TOTAL_OF_RECORDS:'总笔数'
    },

    // 待办事项
    Tasks:{
        UPCOMING_TASKS:'待办事项',
        NUMBER:'序号',
        REFERENCE_NUMBER:'参考编号',
        TRANSACTION_TYPE:'交易类别',
        PRESENTOR:'提交人',
        SUBMISSION_TIME:'提交时间'
    },
   
    // 拟订交易
    DRAFT_TRANSACTION:{
        UPLOAD_METHOD:'上载方式',
        TEMPORARY_STORAGE_TIME:'暂存时间',
        MANUAL_INPUT:'手动输入',
        FILE_UPLOAD:'档案上载'
    },

    // 提示通知
    NOTIFICATION:{
        REMINDER_NOTIFICATION:'提示通知',
        NOTIFICATION:'通知',
        TIME_OF_RECEIPT:'接收时间',
        ALL:'全部',
        UNREAD:'未读',
        CLEAR_UNREAD:'清除未读',
        
    },
    MANAGEMENT:{
        SHORTCUT_MENU_MANAGEMENT:'快捷选单管理',
        SELECTED_FUNCTION:'已选功能',
        CANCEL:'取消',
        COMPLETE:'完成',
        COMMONLY_USE:'最多可增加5个常用功能'

    }

}