/*
 * @Author: your name
 * @Date: 2022-02-11 14:41:17
 * @LastEditTime: 2022-07-04 20:37:36
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit2.
 * @FilePath: \ss-cibs-prc-custpc\src\i18n\home\zh-XG.js
 */
export default {
    //首页
    HOME:{
        WELCOME_BACK:"您好！歡迎回來！",
        SUCCESSFUL_LOGON:"上次登錄時間",
        MY_SETTING:"個人設定",
        SHORTCUT_FUNCTION:"快捷選單",
        MY_SETTINGS:"設置",
        ASSET_VIEW:"資產視圖(港币)",
        RECENT_TRANSFER:"最近轉賬",
        MORE:"更多",
        UPCOMING_TASKS:"待辦任務",
        DRAFT_TRANSACTION:"擬訂交易",
        MESSAGE_NOTIFICATION:"提示通知",
        ANNOUNCEMENT_NOTICE:'公告通知',
        INVESTMENT:"1.投資”包含投資帳戶和股票託管帳戶結餘",
        STOCK_ACCOUNT:"2.股票帳戶結餘為T-1市值",
        PASSWORD_IMMEDIATELY:'您的登入密码已长时间未修改，为了保障证您的账户安全，请立即修改密码。',
        CHANGE_NOW:'立即修改',
        REMIND_ME:'30天后提醒我',
        CORPORATE_INTERNET_BANKING:'您确定退出企业网上银行',
        LOG_OFF_NOW:'立即退出',
        AUTOMATICALLY_LOGGED_OFF:'您已长时间未操作企业网银系统，为保障用户安全，您将于30秒后自动退出。',
        LOGOUT_SUCCESSFUL:'成功退出'
    },

    // 公告
    NOTICE: {
        ANNOUNCEMENT_TITLE: '公告標題',
        RELEASE_DATE: '發佈日期',
        SERIAL_NUMBER: '序號',
        NUMBERING: '編號',
        TITLE: "標題",
        RELEASE_TIME: "發佈時間",
        OPERATE: '操作',
        RESET: '重置',
        DETAILS: '詳情',
        ENQUIRY: '查詢',
        PLEASE_ENTER: '請輸入公告標題',
        ANNOUNCEMENT_DETAILS: '公告詳情',
        GO_TO_CHECK:'去查看'
    },
     // 最近转账
     TRANSCTIONS:{
        RECENT_TRANSFER:'最近轉賬',
        MORE:'更多',
        TOTAL_OF_RECORDS:'總筆數'
    },

    // 待办事项
    Tasks:{
        UPCOMING_TASKS:'待辦事項',
        NUMBER:'序號',
        REFERENCE_NUMBER:'參考編號',
        TRANSACTION_TYPE:'交易類別',
        PRESENTOR:'提交人',
        SUBMISSION_TIME:'提交時間'
    },
   
    // 拟订交易
    DRAFT_TRANSACTION:{
        UPLOAD_METHOD:'上載方式',
        Temporary_Storage_Time:'暫存時間',
        MANUAL_INPUT:'手動輸入',
        FILE_UPLOAD:'檔案上載'
    },

    // 提示通知
    NOTIFICATION:{
        REMINDER_NOTIFICATION:'提示通知',
        NOTIFICATION:'通知',
        TIME_OF_RECEIPT:'接收時間',
        ALL:'全部',
        UNREAD:'未讀',
        Clear_Unread:'清除未讀'
    }


}