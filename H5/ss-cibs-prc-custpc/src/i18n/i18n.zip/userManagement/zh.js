export default {
  //用户户管理
  USER_MANAGEMENT: {
    USER_TYPE_COLON: '用户类型:',
    USER_TYPE: '用户类型',
    USER_CHINESE_COLON: '用户中文名称：',
    USER_CHINESE_NAME: '用户中文名称',
    USER_ENGLISH_COLON: '用户英文名称：',
    USER_ENGLISH_NAME: '用户英文名称',
    USER_STATUS_COLON: '用户状态：',
    USER_STATUS: '用户状态',
    ROLT_TYPR_ALL: "全部",
    ADMINISTRATOR: "管理员",
    REPORTER: "录入员",
    AUTHORIZER: "授权员",
    USERNAME: "用户名",
    AUTHORIZATION_LEVEL: '授权级别',
    FA: '是否开通双重认证',
    SMS: '流动电话',
    ENABLE: '启用',
    DEACTIVATE: '停用',
    CHECH_DETAIL: '查看详情',
    RESET_PASSWORD_TIPS: '是否确定要重新重置该用户的网银登录密码？',
    RESAON_RESET_PASSWORD: '重置密码的原因：',
    FORGOT_PASSWORD: '忘记密码',
    PASSWORD_NOT_RECEIVED: '未收到密码',
    DEACTIVATE_THIS_USER_TIPS: '是否确定停用该用户？',
    ENABLE_THIS_USER_TIPS: '是否确定启用该用户？',

    // ============2022-6-3==============
    INPUT_USER_CHINESE_NAME: '请输入用户中文名称',
    INPUT_USER_ENGLISH_NAME: '请输入用户英文名称',
    CARDTYPE_COLON: '证件类型：',
    PLEASE_SELECT: '请选择',

  },
}