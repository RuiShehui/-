export default {
    // 用户管理
    USER_MANAGERMENT: {
        login_username: '登錄用戶名',
        username: '用戶姓名',
        user_status: '用戶狀態',
        add_operator: '新增操作員'
    }
}