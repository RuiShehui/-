export default {
    // 用户管理
    USER_MANAGERMENT: {
        login_username: 'Login Username',
        username: 'username',
        user_status: 'user status',
        add_operator: 'Add operator'
    }
}