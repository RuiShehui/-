export default {
    // 用户管理
    USER_MANAGERMENT: {
        login_username: '登录用户名',
        username: '用户姓名',
        user_status: '用户状态',
        add_operator: '新增操作员'
    }
}