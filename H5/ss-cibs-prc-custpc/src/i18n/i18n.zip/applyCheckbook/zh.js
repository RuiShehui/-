/*
 * @Author: ZhangZhen
 * @Date: 2022-03-04 09:19:11
 * @LastEditTime: 2022-04-18 10:43:35
 * @LastEditors: ZhangZhen
 * @Description: Zz's design
 * @FilePath: \webbank-pc\src\i18n\applyCheckbook\zh.js
 */
export default {
  //支票簿

  HEAD: {
    Steps: [{
        title: '填写信息'
      },
      {
        title: '确认信息'
      },
      {
        title: '提交结果'
      }
    ],
    Payer_iPayer: '申请信息',
    Current_account: '往来账户',
    Delivery_method: '领取方式',
    Surface_mail: '快递邮寄',
    Autrization_reminder: '授权提醒',
    Send_reminder: '（系统将给提醒人，发送一封待授权提醒邮件）',
    Reminder: '提醒人',
    A_level: 'A級',
    B_level: 'B級',
    C_level: 'C級',
    Reset: '重置',
    Next: '下一步',

  },
  TIPS: {
    Tips: '溫馨提示',
    Tips_one: '1.支票簿将以平邮（本港丶澳门及中国(台湾除外)地址）或空邮形式（台湾或海外地址）寄出，邮寄地址为上述往来户口于本行记录之通讯地址。',
    Tips_two: '2.成功申请将收到短讯或信件通知。如 阁下于14日内仍未收到支票簿，请于办公时间内与本行客户服务代表联络。',
    Tips_three: '3.每次申请将会获得壹本支票簿。'
  }


}