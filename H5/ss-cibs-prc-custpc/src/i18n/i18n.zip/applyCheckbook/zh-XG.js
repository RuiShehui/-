export default {
  //支票簿
  
  HEAD: {
     Steps:[
       {
         title:'填寫資訊'
       },
       {
        title:'確認資訊'
      },
      {
        title:'提交結果'
      }
     ],
     Payer_iPayer :'申請資訊',
          Current_account:'往來帳戶',
          Delivery_method:'領取方式',
          Surface_mail:'快遞郵寄',
          Autrization_reminder:'授權提醒',
          Send_reminder:'（系統將給提醒人，發送一封待授權提醒郵件）',
          Reminder:'提醒人',
          A_level:'A級',
          B_level:'B級',
          C_level:'C級',
          Reset:'重置',
          Next:'下一步',
   
    
  },
  TIPS:{
    Tips:'温馨提示',
    Tips_one:'1.支票簿將以平郵（本港丶澳門及中國(臺灣除外)地址）或空郵形式（臺灣或海外地址）寄出，郵寄地址為上述往來戶口於本行記錄之通訊地址。',
    Tips_two:'2.成功申請將收到短訊或信件通知。如 閣下於14日內仍未收到支票簿，請於辦公時間內與本行客戶服務代表聯絡。',
    Tips_three:'3.每次申請將會獲得壹本支票簿。'
  }


}