/*
 * @Author: ZhangZhen
 * @Date: 2022-03-04 09:19:11
 * @LastEditTime: 2022-04-18 10:43:25
 * @LastEditors: ZhangZhen
 * @Description: Zz's design
 * @FilePath: \webbank-pc\src\i18n\applyCheckbook\en.js
 */
export default {
  //支票簿

  HEAD: {
    Steps: [{
        title: 'Fill in the information'
      },
      {
        title: 'Confirm information'
      },
      {
        title: 'Submit result'
      }
    ],
    Payer_iPayer: 'Application Information',
    Current_account: 'Current Account',
    Delivery_method: 'Delivery Method',
    Surface_mail: 'Surface Mail',
    Autrization_reminder: 'Authorization reminder',
    Send_reminder: '(The system will send a reminder email pending authorization to the reminder)',
    Reminder: 'Reminder',
    A_level: 'A_level',
    B_level: 'B_level',
    C_level: 'C-level',
    Reset: 'Reset',
    Next: 'Next',

  },
  TIPS: {
    Tips: 'Tips',
    Tips_one: '1.The cheque book will be sent to the correspondence address of the above current account retained at the Bank’s records by surface mail (HK, Macau and China (Except Taiwan) Address) or airmail (Taiwan or Overseas Address).',
    Tips_two: '2.Acknowledged SMS or letter will be received upon successful application. If you do not receive the cheque book within 14 days, please contact our Customer Services Representative during office hours.',
    Tips_three: 'One cheque book will be issued per request.'
  }


}