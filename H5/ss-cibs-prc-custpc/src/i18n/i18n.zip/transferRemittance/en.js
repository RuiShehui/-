/*
 * @Author: ZhangZhen
 * @Date: 2022-02-10 10:01:42
 * @LastEditTime: 2022-07-05 11:29:16
 * @LastEditors: zhangcheng
 * @Description: Zz's design
 * @FilePath: \ss-cibs-prc-custpc\src\i18n\transferRemittance\en.js
 */
export default {
  // 付款
  PAYMENT: {
    PAYMENT_ACCOUNT: "Transfer From",
    ACCOUNT_NAME: "Account Name",
    AVAILABLE_BALANCE: "Available Balance",
    APPOINTMENT_PROCESS: "Appointment processing",
    APPOINTMENT_DATE: "date",
    RETRY_DEDUCTION: "Retry the Debit",
    RETRY_TIPS: "If the debit has failed for the first time on the appointment date due to insufficient available balance, the account will be debited again in the afternoon of the same day.",
    PAYEE_TYPE: "Payee Type",
    MY_ACCOUNT: "Chong Hing Bank Account under my name ",
    REGISTERED_ACCOUNT: "Registered Third-party Account",
    REGISTRIED_ACCOUNT_QUERY: "Registered Account(s) Enquiry",
    NO_REGISTERED_ACCOUNT: "Non-registered Account",
    IMPORT_NEAREST_PEYEE: "Recent Payee",
    RECEIVE_ACCOUNT: "Fund Receiving Account",
    PAYEE_NAME: "Receiving account name",
    TRANSFER_AMOUNT: "Transfer Amount",
    POSTSCRIPT: "Message (To the payee)",
    REMARKS: "Remarks",
    IS_REGISTERED: "Register this Account",
    TEMPORARY_TRANSACTION: "Save a tentative transaction temporarily", // Temporary transaction draft
    REMINDER: "Reminder",
    PAYER_INFO: "Payer Information",
    PAYEE_INFO: "Payee information",
    RECEIVE_BANK_INFO: "Receiving Bank Information",
    AUTHORIZATION_REMINDER: "Authorization reminder",
    AUTHORIZATION_TIPS: "(The system will send a reminder email pending authorization to the reminder)",
    FILL_TRANSFER_INFO: "Fill in the transfer information",
    CONFIRM_TRANSFER_INFO: "Confirm transfer information",
    SUBMIT_RESULT: "Submit result",
    CLASS_A: "A-level",
    CLASS_B: "B-level",
    CLASS_C: "C-level",
    PAYEE_IDENTIFY_WAY: "Recipient Identification Method",
    EMAIL_ADDRESS: "Email Address",
    MOBILE_PHONE_NUMBER: "Mobile Phone Number",
    MOBILE_PHONE_NUMBER_NOT_VALID: "Mobile phone number format is incorrect",
    DESIGNATED_RECEIVE_BANK: "Designated Receiving Bank/Institution",
    RECEIVE_BANK: "Fund Receiving Bank/Institution",
    FEE_DEDUCTION_ACCOUNT: "Account for debiting the handling fee",
    WARM_TIPS: "Tips",
    INLINE_TIPS_1: [
      "1.Service Hours: 24 hours",
      "2.Instruction of transferring funds to bank account or credit card account of the Bank will be processed immediately. (Fund transfer to non-registered third-party credit card account is not accepted).",
      "3.Only the same currency transfer is applicable for foreign currency transfer within the Bank.",
      "4.Please click here to view the details of daily aggregate transfer limits. In case you want to set the transaction limit to the Bank's maximum transaction limit, you are required to apply in person at any branch of the Bank in Hong Kong.",
      "5.For fund transfer to credit card account, only same currency is accepted.",
      "6.For the Bank's charges of cash advance, please refer to Chong Hing Credit Card Charges Table and Chong Hing UnionPay Dual Currency Credit Card Charges Table.",
      "After the transaction has been executed, a reference number will be displayed for making enquiry in future. If there is no reference number displayed or you are not sure whether the transaction has been executed, please check the balance of the relevant account before performing the transaction again in order to avoid repeated transaction."
    ],
    INLINE_TIPS_2: [],
    INLINE_TIPS_3: [],
    FAST_TIPS: [
      "1.Service Hours: 24 hours.",
      "2.Please refer to the Service Charges on the Bank's website.",
      "3.Any instructions once accepted and processed by the Bank cannot be cancelled, amended, supplemented or revoked by the customer.",
      "4.Please click here to view the details of daily aggregate transfer limits. In case you want to set the transaction limit to the Bank's maximum transaction limit, you are required to apply in person at any branch of the Bank in Hong Kong.",
      "5.Customer shall warrant to the Bank on the genuineness, accuracy, adequacy and completeness of his/her instructions, for which the Bank shall not be responsible or liable in whatever manners.",
      "6.After the transaction has been executed, a reference number will be displayed for making enquiry in future. If there is no reference number displayed or you are not sure whether the transaction has been executed, please check the balance of the relevant account before performing the transaction again in order to avoid repeated transaction."
    ],
    FAST_POLICIES: '',
    LOCAL_TIPS: [
      '1. Service Charge (To be debited from "From Account"): ',
      'HKD 50 (For HKD Fund Transfer)',
      'USD 6 (For USD Fund Transfer) ',
      'CNY 40(For CNY Fund Transfer) ',
      'EUR 6 (For EUR Fund Transfer)',
      '2. Service Hour:9:00 am to 5:00 pm (Mondays to Fridays, excluding Saturdays, Sundays or Public Holidays).',
      '3. Processing Time: (Only applicable for HKD, CNY, USD and EUR transfer)For instructions accepted between 9:00am and 4:30pm, funds transferred will be available in the beneficiary\'s bank on the same day.',
      '4.You can submit the "New Limit Setting for Online Fund Transfer / Telegraphic Transfer to Other Banks" application form at any of our Branches to uplift relevant transaction daily limit per account.',
      '5. Any instruction once accepted and processed by the Bank shall not be cancelled, amended, supplemented or revoked by the customer.',
      '6. Please click here to view the details of daily transfer limits in aggregate. You are only allowed to set the transaction limit to the Bank\'s maximum transaction limit through application in person at our any branch in Hong Kong.',
      '7. Customer shall warrant to the Bank on the genuineness, accuracy, adequacy and completeness of his/her instructions, for which the Bank shall not be responsible or liable in whatever manners.',
      '8. Your pre-registered account will be removed if there is no transaction performed in the past 36 months. Please visit any of our branches to register the account again.',
      '9. After the transaction has been executed, a reference number will be displayed for making enquiry in future. If there is no reference number displayed on screen or you are not sure whether the transaction has been executed, please check the balance of relevant account before performing the transaction again in order to avoid repeated transaction.'
    ],
    GLOBAL_TIPS: [
      'Cable Charge: HKD 110 per transaction',
      'Service Hours: 24 hours a day (Except Sunday & Public Holidays) Processing Time: For Mondays to Fridays',
      'Processing Time:',
      'For Mondays to Fridays',
      '- Remittance Currency: CNY',
      "  &nbsp; 1. Instructions accepted on or before 3:00 pm will be processed on the same day.",
      " &nbsp; 2. Instruction received after 3:00 pm will be processed on the next business day.",
      '- Remittance Currency: Other Currency (Except CNY)',
      "  &nbsp; 1.  Instructions accepted on or before 4:00 pm will be processed on the same day.",
      " &nbsp; 2. Instruction received after 4:00 pm will be processed on the next business day.",
      ' For Saturdays',
      ' &nbsp; &nbsp; Instructions would be processed on next working day.',
      '1. I / We acknowledge and agree that for the purpose of carrying out this remittance instruction and record thereof by the Bank, my / our personal data and other information may be transferred to third parties including those located in or outside Hong Kong from time to time.',
      '2. I / We hereby request the Bank to effect the above remittance subject to the "Remittance Conditions", Internet Banking Services Terms and Conditions, and Accounts Rules (as may be amended by the Bank from time to time at its sole discretion, which I / we have read, understood and agree to be bound by them.',
      '3. I / We hereby warrant to the Bank on the genuineness, accuracy, adequacy and completeness of my/our instructions to the Bank from time to time, for which the Bank shall not be responsible or liable in whatever manner.',
      '4. Any instruction once accepted and processed by the Bank shall not be cancelled, amended, supplemented or revoked by me/us unless with the Bank\'s consent.',
      '5. Please click here to view the details of daily transfer limits in aggregate. You are only allowed to set the transaction limit to the Bank\'s maximum transaction limit through application in person at our any branch in Hong Kong.',
      '6. After the transaction has been executed, a reference number will be displayed for making enquiry in future. If there is no reference number displayed on screen or you are not sure whether the transaction has been executed, please check the balance of relevant account before performing the transaction again in order to avoid repeated transaction.',
      '7. Hong Kong Resident can remit up to a maximum of CNY80,000 per person per day. Customer\'s daily outward remittance amount may be checked by the CNY clearing bank. The account name of your beneficiary account in Mainland China must be identical with that of your CNY savings account with Chong Hing Bank.',
      '8. If you submit a CNY remittance instruction via Internet Banking on the same day after you have made a CNY remittance at a branch, and the total remittance amount exceeds the maximum daily limit of CNY 80,000, the remittance instruction made via Internet Banking might be rejected or executed on the next working day.',
      '9. Your pre-registered account will be removed if there is no transaction performed in the past 36 months. Please visit any of our branches to register the account again.',
    ],
    CONFIRM_PROVE: "Confirm Auth",
    CANCEL_PROVE: "Cancel Auth",
    CURRENCY_NOT_VALID: 'Currency type does not match with the Payment Account Please select again.',
    A_LEVEL_AUTHOR: 'A-Level authors',
    B_LEVEL_AUTHOR: 'B-Level authors',
    C_LEVEL_AUTHOR: 'C-Level authors',
    RESULT_ASSIST: 'If you need assistance, please call our customer service hotline (852) 3768 6888',
    TO_AUTH_TIP: 'Please go to the authorization center to check the authorization progress',
    SUCCESS_TRADE: '交易成功',
    FAIL_REASON: 'Reason for failure',
    GENERATE_PDF: 'Generate PDF',
    /** 2022-02-24 */
    INNER_TRANSFER: 'Transfer Within Bank',
    FAST_TRANSFER: 'FPS',
    LOCAL_TRANSFER: 'CHATS （EUR/USD）',
    REMMITANCE: 'Global remittance',
    SUB_TRANS: 'Bulk Transfer',
    AUTO_TRANS_AND_RECEIVE: 'Transfer money',
    SEND_SALARY: 'Bulk Transaction Enquiry',
    RESPOS_HANDLE_DATE: 'Appointment processing date',
    PAYMENT_METHOD: 'Payment method',
    PAYMENT_METHOD_TIP1: 'SHA - I shall pay the fees of Chong Hing Bank, and the recipient pays the fees of other banks (deducted from the remittance).',
    PAYMENT_METHOD_TIP2: 'BEN – The fees of Chong Hing Bank f and other banks are to be paid by the recipient (deducted from the remittance).',
    PAYMENT_METHOD_TIP3: 'OUR - I shall pay the fees of Chong Hing Bank and other banks.',
    FEE_DEBIT_ACCOUNT: 'Fee Debit Account',
    RECEIVER_ADDRESS: 'Payee Address',
    RECEIVER_COUNTRY: 'Country/Region',
    ITIONALTEXT: '附言输入有误，请重新输入',
    ACCT_NO_OR_IBAN: 'Account No./IBAN',
    RECEIVE_METHOD: 'Payee Type',
    RECEIVER_BANK_COUNTRY: 'Payee Bank Country/Region',
    /** 2022-02-24 */
    /** 2022-02-25 */
    // PAY_AMOUNT: 'Transfer Money',
    PAYEE_AMOUNT: 'Remittance Amount',
    BANK_NO: 'Bank No',
    BANK_NAME: 'Bank Name',
    BANK_ADDRESS: 'Bank Address',
    PAYEE_COUNTRY_CODE: 'Payee Bank Country/Region',
    MAY_BE_INTEREST: 'Using an overdraft facility may incur interest',
    LACK_OF_BALANCE_AND_TIP: 'The available balance in the account for handling fee deduction is insufficient, please make up the funds before the appointment date',
    SAVE_DRAFT_SUCCESS: 'Draft saved successfully.',
    /** 2022-02-25 */
    /** 2022-02-28 */
    TT_PURPOSE_CODE: 'Remittance Destination Code',
    CHARGE_CCY: 'Handling Fee',
    FEE: 'fee',
    AMOUNT_RANGE: 'Amount Range',
    DETAIL_DATE: 'Transfer Date',
    UNFOLD_MENU: 'Unfold',
    FOLD_MENU: 'fold',
    TRANS_TYPE: "Transfer Type",
    ONE_MORE_TRANS: 'Transfer Again',
    WEBBANK_FLOW_NO: 'Online banking serial number',
    WEBBANK_REF_NO: 'Reference Number',
    AMOUNT_RANGE_ERROR: 'Start amount can\'t morethen lase amount',
    /** 2022-02-28 */
    /** 2022-03-03 */
    BATCH_DEAL_STATUS: 'Bulk Status',
    CURRENT_DATE: 'Dangri',
    TOTAL_AMOUNT: 'Total Amount',
    TOTAL_TRANS: 'Total Count',
    DEAL_AMOUNT: 'Transaction Amount',
    DEAL_TRANS: 'Transaction Count',
    INPUT_TYPE: 'Entry Method',
    REGISTER_CODE: 'Registration Number',
    INTRA_BANK_ACCOUNT: 'Intra-bank Account',
    LOCAL_BANK_ACCOUNT: 'Local Inter-bank Account',
    REMITTANCE_ACCOUNT: 'Wire Transfer Account',
    NEW: 'New',
    TRANS: 'Transfer',
    /** 2022-03-03 */
    /** 2022-03-04 */
    SWIFT_CODE_ILEGAL: 'SWIFT Code is Ilegal',
    COUNTRY_NO: 'Country Code',
    AREA_NO: 'Region Code',
    SYSTEM_TO_REMINDED: '(The system will send a reminder email to the reminder to be authorized)',
    /** 2022-03-04 */
    /** 2022-03-07 */
    TRANS_NUM: '',
    INCOME_TOTAL: '',
    OUTPUT_TOTAL: '',
    /** 2022-03-07 */
    /** 2022-03-08 */
    CONFIRM_REMOVE_REGISTERED_ACCOUNT: '',
    REGISTERED_INLINE_TIPS: [
      '1.Service Hours: 24 hours',
      '2.Fund transfer to bank account or credit card account of the bank will be processed immediately. (Fund transfer to non-registered third party credit card account is not accepted)',
      '3.Only the same currency transfer is applicable for transfer within bank.',
      '4.Please click here to view the details of daily transfer limits in aggregate. You are only allowed to set the transaction limit to the Bank\'s maximum transaction limit through application in person at our any branch in Hong Kong.',
      '5.For transfer to credit card account, only same currency is allowed.',
      '6.For the Bank\'s charge of cash advance fee, please refer to Chong Hing Credit Card Charges Table and Chong Hing UnionPay Dual Currency Credit Card Charges Table.',
      'After the transaction has been executed, a reference number will be displayed for making enquiry in future. If there is no reference number displayed on screen or you are not sure whether the transaction has been executed, please check the balance of relevant account before performing the transaction again in order to avoid repeated transaction.',
    ],
    /** 2022-03-08 */
    /** 2022-03-10 */
    CREDIT_CURRENCY: '',
    CREDIT_CARD: 'Credit Card',
    EMAIL_NO_VALID: '',
    PRESET_PAYEE_ACCOUNT: '',
    PRESET_PAYEE_BANK: 'Default Fund Receiving Bank',
    CHUANGXING_BANK: '',
    CHUANGXING_BANK_CPY: 'Chong Hing Bank Limited',
    /** 2022-03-10 */
    /** 2022-03-11 */
    ADD_INFOS: '',
    CONFIRM_ADD_INFOS: '',
    ADD_RESULT: '',
    UPDATE_INFOS: '',
    CONFIRM_UPDATE_INFOS: '',
    UPDATE_RESULT: '',
    /** 2022-03-11 */
    /** 2022-03-23 */
    ACCT_ADDRESS: 'Country/Region (Payee)',
    ACCT_NAME: 'Payee Name',
    PAY_ACCT_NAME: 'Account/Telephone/Email/FPS ID',
    /** 2022-03-23 */
    /** 2022-04-01 */
    AUTH_CENTER: 'ShouquanZhongxin',
    /** 2022-04-01 */
    /** 2022-04-24 */
    HIGH_RISK_TRADE_TIP: 'Please use Mobile Token through Corporate Mobile Banking to conduct high-risk transactions in internet Banking',
    /** 2022-04-24 */
    /** 2022-04-28 */
    OVER_BALANCE_TIP: 'Using an overdraft facility may incur interest !',
    ELEC_FEE: 'Cable Charge',
    /** 2022-04-28 */
    /** 2022-05-06 */
    BANK_PROXY_FEE: 'Bank Agency Fee',
    /** 2022-05-06 */
    /** 2022-05-07 */
    GOODS_TRADE: '',
    SERVICE_TRADE: '',
    CAPITAL_TRANSFER: '',
    CURRENT_ACCOUNT_TRANSCATION: '',
    CHARITY_DONATION: '',
    /** 2022-05-07 */
    /** 2022-05-10 */
    BANK_AND_ADDRESS: '',
    /** 2022-05-16 */
    DEBIT_ACCT_DORMANT: '',
    DEBIT_ACCT_FROZEN: '',
    DEBIT_ACCT_CLOSED: '',
    /** 2022-05-16 */
    /** 2022-05-17 */
    INCLUDE_SWIFT_ILEGAL: '',
    /** 2022-05-17 */
    /** 2022-05-26 */
    CREDIT_ACCT_NOT_VALID: '',
    /** 2022-05-26 */
    /** 2022-05-31 */
    RECENT_TRANSFER: 'Rencent Transfer Record',
    /** 2022-05-31 */
    /** 2022-06-01 */
    CHARGE_ACCT_DORMANT: '',
    CHARGE_ACCT_FROZEN: '',
    CHARGE_ACCT_CLOSED: '',
    /** 2022-06-01 */
    /** 2022-06-07 */
    NOT_EDIT_TIP: 'not edit todo',
    /** 2022-06-07 */
    /** 2022-06-21 */
    MODIFY_APPOINTMENT: 'Modify Appointment',
    DETAIL: 'Detail',
    AUTH_NO: 'Authorization number',
    PAYER_NAME: 'Payer Name',
    PAYER_BANK: 'Payer Bank/Institution',
    PAYER_AMOUNT: 'Payer Amount',
    /** 2022-06-21 */
    /** 2022-06-30 */
    DELETE_PAYEE: 'Are you sure you want to delete the selected payee?',
    /** 2022-06-30 */
    /** 2022-07-04 */
    PLEASE_INPUT: 'Please enter the %{input}',
    PLEASE_SELECT: 'Please select the %{select}',
    PAYEE_ACCT_NAME: 'Payee Account Name',
    SEARCH_NONE: 'No results found. ',
    ACCT_REGISTED: 'The payment information has been registered, please confirm.',
    PAYEE_ACCT_NAME_ERROR: 'The payee account name is incorrect, please enter again.',
    NO_REGIST_CREDIT_CARD: 'Fund transfer to non-registered credit card account is not supported.',
    ACCT_IS_REGIST: 'The beneficiary has been registered. Please select the registered third-party account for the transfer.',
    NO_CHONGHING: 'The fund receiving account is not a Chong Hing Bank account. Please use other transfer methods.',
    CREATED_PDF: 'Create a PDF file',
    EVERYDAY_LIMIT: 'Please click here to view the details of daily aggregate transfer limits. In case you want to set the transaction limit to the Bank\'s maximum transaction limit, you are required to apply in person at any branch of the Bank in Hong Kong.',
    EXCEED_AMOUNT: 'The transfer amount of the transaction exceeds the available balance and cannot be authorised.',
    NOT_ACCEPT: 'Not Accepted',
    ACCEPT: 'Accepted',
    PHONE_NUMBER: 'Telephone Number',
    COUNTRY_REGION_CODE: 'Country/Region Codes',
    PAYEE_BANK_NOT_FPS: 'The payment information does not support FPS transfer, please confirm.',
    CHARGE_ACCOUNT_NO_MONEY: 'Available balance in the handling fee deduction account is insufficient to complete the transaction.',
    APP_CHARGE_ACCOUNT_NO_MONEY: 'The available balance in the account for handling fee deduction is insufficient. Please make up the amount before the scheduled processing date.',
    LOCAL_SEVER_TIME: 'Out of service hours currently. Foreign currency transfer (EUR/USD) service hours are from 9:00 am to 5:00 pm (Monday to Friday), except Saturday, Sunday and Public Holidays including Public Holidays of the Bank\'s location. ',
    CHARGE_NO_AMOUNT_AUTH: 'The account for handling fee deduction is insufficient and cannot be authorised.',
    APP_ACCT_NO_AMOUNT: 'The available balance of the fee deduction account is insufficient. Please make up the amount before the scheduled processing date.',
    ACCT_NO_AMOUNT: 'The available balance in the fee debit account is insufficient to complete the transaction.',
    PAYEE_NAME_SUP: 'The payee name in the payee address field is incomplete. Please continue to enter. If there is an address, you can enter it after the name.',
    BANK_NAME_SUP: 'The bank name in the bank address field is incomplete. Please continue to enter. If there is an address, you can enter it after the name.',
    /** 2022-07-04 */
    /** 2022-07-05 */
    ACCT_IS_REGIST_COMFIRM: 'The fund receiving account has been registered. Please confirm.',
    ACCT_DID_NOT_REGIST: 'The fund receiving account is the account of a company where you are located. No registration is required.',
    ACCT_NOT_INNER: 'The fund receiving account is not a Chong Hing Bank account. Please register for a local inter-bank account.',
    NOT_CHANGE: 'You have not modified the payee information.',
    CONFIRM_DELETE: 'Are you sure you want to delete the selected registered account with the Bank?',
    MOBILE_IS_NOT_REGIST: 'The %{type} has not registered for FPS.',
    IS_REGIST: 'The payee has already been registered. Please confirm.',
    PAYEE_UN_REGIST: 'The payee has not registered for FPS.',
    IS_DELETE_REGIST_FPS: 'Are you sure to delete the registered third-party account for %{type}?',
    BANK_COUNTRY_REGION: 'Bank Country/Region',
    PAYEE_ACCT_ERROR: 'The entered credit account is incorrect. Please enter again.',
    START_DATE: 'Start Date',
    END_DATE: 'End Date',
    COST: 'Fee',
    NOT_CHANGE_DATA: 'You have not modified the scheduled processing date.',
    CANCEL_APP: 'You are cancelling the scheduled transaction now. Please confirm.',
    CAN_NOT_CANCEL: 'Today is the scheduled processing  date The transaction cannot be cancelled.',
    CANT_NOT_CHANGE: 'Today is the scheduled processing date. The scheduled processing date cannot be modified.',
    /** 2022-07-05 */
  },
  // 预约交易管理
  APPOINTTRACTION: {
    TRANS_TYPE: "Transaction Type",
    LOCAL_INTERBANK: 'Local Cross',
    TELEGRAPHIC_TRANSFER: 'Global Remittance',
    FPS_TRANSFEP: 'FPS',
    CHATS_TRANSFER: 'CHATS(EUR/USD)',
    BATCH_TRANSFER: 'Bulk Transfer',
    BATCH_PAYDAY: 'Payroll In Bulk',
    BATCH_COLLECT: 'Branch Collection',
    SUBMIT_TIME: 'Submission Time'
  },
  // 批量
  BRANCH_TRANSFER: {
    ONLINE_EDIT: 'Online Editing',
    FILE_UPLOAD: 'File Upload',
  }
}
