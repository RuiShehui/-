/*
 * @Author: ZhangZhen
 * @Date: 2022-02-23 14:33:04
 * @LastEditTime: 2022-07-05 11:28:23
 * @LastEditors: zhangcheng
 * @Description: Zz's design
 * @FilePath: \ss-cibs-prc-custpc\src\i18n\transferRemittance\zh-XG.js
 */
export default {
  // 付款
  PAYMENT: {
    PAYMENT_ACCOUNT: "付款帳戶",
    ACCOUNT_NAME: "帳戶名稱",
    AVAILABLE_BALANCE: "可用結餘",
    APPOINTMENT_PROCESS: "预约处理",
    APPOINTMENT_DATE: "預約處理日期",
    RETRY_DEDUCTION: "重試扣賬",
    RETRY_TIPS: "如預約日期首次扣賬因可用結餘不足導致轉賬失敗，本行將於同日下午再次扣賬。",
    PAYEE_TYPE: "收款人類型",
    MY_ACCOUNT: "本人名下創興銀行賬戶",
    REGISTERED_ACCOUNT: "已登記第三者賬戶",
    REGISTRIED_ACCOUNT_QUERY: "已登記賬戶查詢",
    NO_REGISTERED_ACCOUNT: "未登記賬戶",
    IMPORT_NEAREST_PEYEE: "最近收款人",
    RECEIVE_ACCOUNT: "收款賬戶",
    PAYEE_NAME: "收款戶名",
    TRANSFER_AMOUNT: "轉賬金額",
    POSTSCRIPT: "附言（致收款人）",
    REMARKS: "備註",
    IS_REGISTERED: "登記此賬戶",
    TEMPORARY_TRANSACTION: "暫存擬訂交易",
    REMINDER: "提醒人",
    PAYER_INFO: "付款人資料",
    PAYEE_INFO: "收款人資料",
    RECEIVE_BANK_INFO: "收款銀行資訊",
    AUTHORIZATION_REMINDER: "授權提醒",
    AUTHORIZATION_TIPS: "（系統將給提醒人，發送一封待授權提醒郵件）",
    FILL_TRANSFER_INFO: "填寫轉賬資訊",
    CONFIRM_TRANSFER_INFO: "確認轉賬資訊",
    SUBMIT_RESULT: "提交結果",
    CLASS_A: "A級",
    CLASS_B: "B級",
    CLASS_C: "C級",
    PAYEE_IDENTIFY_WAY: "收款人識別方式",
    EMAIL_ADDRESS: "電郵地址",
    MOBILE_PHONE_NUMBER: "流動電話號碼",
    MOBILE_PHONE_NUMBER_NOT_VALID: "流動電話號碼格式錯誤",
    DESIGNATED_RECEIVE_BANK: "指定收款銀行/機構",
    RECEIVE_BANK: "收款銀行/機構",
    FEE_DEDUCTION_ACCOUNT: "手續費扣款賬戶", //
    WARM_TIPS: "溫馨提示",
    INLINE_TIPS_1: [
      "1.服務時間： 24 小時",
      "2.轉賬至本行銀行賬戶或信用卡賬戶的交易指示將即時處理（不接受轉賬至非登記第三者信用卡賬戶）。",
      "3.本行同行外幣轉賬功能只適用於同幣種轉賬。",
      "4.請按此查閱每日累積轉賬限額。如需設定交易限額至本行的最高交易限額，您必須親臨本行於香港任何分行申請。",
      "5.只接受以相同貨幣轉賬至信用卡賬戶。",
      "6.有關本行現金透支收費詳情，請參閱創興信用卡收費表及創興銀聯雙幣信用卡收費表。",
      "7.當交易指示已被執行後，畫面會顯示一個參考編號，以便您於日後作出查核。如畫面沒有顯示參考編號或您不確定有關交易是否已執行，請於重新進行交易前先查詢相關賬戶之結餘，以避免重複交易。"
    ],
    INLINE_TIPS_2: [],
    INLINE_TIPS_3: [],
    FAST_TIPS: [
      "1.服務時間： 24 小時",
      "2.敬請參閱本銀行網頁上之服務收費",
      "3.任何指示一經銀行接納及執行，均不能被取消、修改、補充或撤銷。",
      "4.請按此查閱每日累積轉賬限額。如需設定交易限額至本行的最高交易限額，閣下必須親臨本行於香港任何分行申請。",
      "5.由於本行未能核對 閣下所輸入之資料的準確性，客戶必須向銀行保証該指示之真實性、準確性、足夠性及完整性，本行將不會負擔或負上任何有關責任。",
      "6.當交易指示已被執行後，畫面會顯示一個參考編號，以便您於日後作出查核。如畫面沒有顯示參考編號或您不確定有關交易是否已執行，請於重新進行交易前先查詢相關帳戶之結餘，以避免重複交易。"
    ],
    FAST_POLICIES: '',
    LOCAL_TIPS: [
      '1、服務收費 (由付款賬戶扣除)：',
      '港元轉賬 - HKD 50',
      '美元轉賬 - USD 6',
      '人民幣轉賬 - CNY 40',
      '歐羅轉賬 - EUR 6',
      '2、服務時間：上午 9 時至下午 5 時(星期一至五，星期六、日及公眾假期除外)。',
      '3、處理時間：(只接受港元、美元、人民幣及歐羅之轉賬)上午9時至下午4時30分所接納之指示，款項可即日轉賬至收款銀行。',
      '4、您可於本行於香港任何分行遞交「新網上轉賬/電匯至其他銀行之交易限額設定」申請表，以提升有關賬戶的每日交易限額。',
      '5、任何指示一經本行接納及執行，均不能取消、修改、補充或撤銷。',
      '6、請按此查閱每日累積轉賬限額。如需設定交易限額至本行的最高交易限額，您必須親臨本行於香港任何分行申請。',
      '7、客戶必須向銀行保證該指示之真實性、準確性、足夠性及完整性，本行將不會負擔或負上任何有關責任。',
      '8、若您已登記的賬戶於過去36個月內沒有進行交易，有關之賬戶將會被移除。如需重新登記該賬戶，請到本行於香港任何分行辦理手續。',
      '9、當交易指示已被執行後，畫面會顯示一個參考編號，以便您於日後作出查核。如畫面沒有顯示參考編號或您不確定有關交易是否已執行，請於重新進行交易前先查詢相關賬戶之結餘，以避免重複交易。'
    ],
    GLOBAL_TIPS: [
      "電報費：每筆交易 HKD 110",
      "服務時間：每日24小時 (星期日及公眾假期除外) ",
      "處理時間：",
      "逢星期一至星期五",
      "- 匯款貨幣：人民幣",
      "  &nbsp; 1. 下午3時前接納之指示將於同一天執行。",
      " &nbsp;2. 下午3時後接納之指示將於下一個工作日執行。",
      "- 匯款貨幣：其他貨幣 (人民幣除外)",
      "  &nbsp; 1. 下午4時前接納之指示將於同一天執行。",
      " &nbsp; 2. 下午4時後接納之指示將於下一個工作日執行。",
      "逢星期六",
      " &nbsp; &nbsp; 指示將於下一個工作日執行。",
      "1、本人(等)確認並同意銀行可不時向(包括香港或香港以外的第三者)提供本人(等)的個人資料及其他資訊以執行及紀錄上述電匯指示。",
      "2、本人(等)已詳閱、瞭解和同意「匯款條件」、「網上銀行服務章則及條款」和「帳戶章則」(不時經銀行單獨酌情修訂及生效)的各項條款並受其約束，茲委託銀行根據該等條款執行以辦理上述電匯指示。",
      "3、本人(等)向銀行保証本人(等)不時發出的指示之真實性、準確性、足夠性及完整性，銀行將不會就該指示負擔或負上任何有關責任。",
      "4、除非获得银行同意，本人（等）之任何指示一经银行接纳及执行，均不能被取消、修改、补充或撤销。",
      "5、請按此查閱每日累積轉賬限額。如需設定交易限額至本行的最高交易限額，閣下必須親臨本行於香港任何分行申請。",
      "6、當交易指示已被執行後，畫面會顯示一個參考編號，以便您於日後作出查核。如畫面沒有顯示參考編號或您不確定有關交易是否已執行，請於重新進行交易前先查詢相關帳戶之結餘，以避免重複交易。",
      "7、香港居民每天最高可電匯人民幣 80,000 元，客戶每日的匯出款額或會由人民幣清算行核查。在內地的收款戶口名稱必須與您的創興銀行人民幣儲蓄戶口名稱完全相同。",
      "8、如閣下當日於分行敘做人民幣匯款後，同日再透過網上銀行提交人民幣匯款指示，而匯款總額超過每日最高匯款金額（人民幣80,000元），該網上銀行之匯款指示可能會被拒納或將順延於下一個工作日執行。",
      "9、若閣下已登記的帳戶於過去三十六個月內沒有進行交易，有關之帳戶將會被移除。如需重新登記該帳戶，請到各分行辦理手續。"
    ],
    CONFIRM_PROVE: "確認認證",
    CANCEL_PROVE: "取消認證",
    CURRENCY_NOT_VALID: '貨幣類別與付款賬戶不符，請重新選擇。',
    A_LEVEL_AUTHOR: 'A級授權人',
    B_LEVEL_AUTHOR: 'B級授權人',
    C_LEVEL_AUTHOR: 'C級授權人',
    /** 2022-02-23 */
    PLEASE_INPUT_AMOUNT: '請輸入轉賬金額',
    AMOUNT_SHOULD_OVER_ZERO: '轉賬金額必須大於0!',
    LACK_OF_BALANCE: '可用結餘不足，請更換其他付款賬戶',
    RESULT_ASSIST: '如需要協助，請致電本行客戶服務熱線（852）3768 6888',
    TO_AUTH_TIP: '請至授權中心查看授權進度',
    SUCCESS_TRADE: '交易成功',
    FAIL_REASON: '失敗原因',
    GENERATE_PDF: '生成PDF',
    /** 2022-02-23 */
    /** 2022-02-24 */
    INNER_TRANSFER: '行內轉賬',
    FAST_TRANSFER: '轉數快',
    LOCAL_TRANSFER: '外幣轉賬（EUR/USD)',
    REMMITANCE: '全球匯款',
    SUB_TRANS: '批量轉賬',
    AUTO_TRANS_AND_RECEIVE: '自動轉賬收款',
    SEND_SALARY: '批量發薪',
    RESPOS_HANDLE_DATE: '預約處理日期',
    PAYMENT_METHOD: '費用支付方式',
    PAYMENT_METHOD_TIP1: 'SHA-本人支付創興銀行之費用，收款人支付其他銀行之費用(從匯款中扣除)。',
    PAYMENT_METHOD_TIP2: 'BEN-創興銀行和其他銀行之費用均由收款人支付 (從匯款中扣除)。',
    PAYMENT_METHOD_TIP3: 'OUR-本人支付創興銀行及其他銀行之費用。',
    FEE_DEBIT_ACCOUNT: '費用扣款帳戶',
    RECEIVER_ADDRESS: '收款人地址',
    RECEIVER_COUNTRY: '國家/地區',
    ACCT_NO_OR_IBAN: '賬戶號碼/IBAN',
    ITIONALTEXT: '附言输入有误，请重新输入',
    RECEIVE_METHOD: '收款方式',
    RECEIVER_BANK_COUNTRY: '收款銀行國家/地區',
    /** 2022-02-24 */
    /** 2022-02-25 */
    // PAY_AMOUNT: '轉賬金額',
    PAYEE_AMOUNT: '匯款金額',
    BANK_NO: '銀行標號',
    BANK_NAME: '銀行名稱',
    BANK_ADDRESS: '銀行名稱',
    PAYEE_COUNTRY_CODE: '收款銀行國家/地區',
    MAY_BE_INTEREST: '使用透支額度可能會產生利息',
    LACK_OF_BALANCE_AND_TIP: '手續費扣款帳戶可用結餘不足，請在預約日期之前補足資金',
    SAVE_DRAFT_SUCCESS: '成功保存草稿',
    /** 2022-02-25 */
    /** 2022-02-28 */
    TT_PURPOSE_CODE: '匯款目的地代碼',
    CHARGE_CCY: '手續費',
    FEE: '匯款金額',
    AMOUNT_RANGE: '金額範圍',
    DETAIL_DATE: '交易日期',
    UNFOLD_MENU: '展開',
    FOLD_MENU: '收起',
    WEBBANK_FLOW_NO: '網銀流水號',
    WEBBANK_REF_NO: '参考编号',
    TRANS_TYPE: "轉賬類型",
    ONE_MORE_TRANS: '再次轉賬',
    AMOUNT_RANGE_ERROR: '起始金額不能大於終止金額',
    /** 2022-02-28 */
    /** 2022-03-03 */
    BATCH_DEAL_STATUS: '批量狀態',
    CURRENT_DATE: '當日',
    TOTAL_AMOUNT: '總金額',
    TOTAL_TRANS: '總筆數',
    DEAL_AMOUNT: '成交金額',
    DEAL_TRANS: '成交筆數',
    INPUT_TYPE: '錄入方式',
    REGISTER_CODE: '登記編號',
    INTRA_BANK_ACCOUNT: '行內賬戶',
    LOCAL_BANK_ACCOUNT: '本地跨行賬戶',
    REMITTANCE_ACCOUNT: '全球匯款賬戶',
    NEW: '新增',
    TRANS: '轉賬',
    /** 2022-03-03 */
    /** 2022-03-04 */
    SWIFT_CODE_ILEGAL: 'SWIFT Code不合法',
    COUNTRY_NO: '國家編號',
    AREA_NO: '地區編號',
    SYSTEM_TO_REMINDED: '（系統將給提醒人，發送一封待授權提醒郵件）',
    /** 2022-03-04 */
    /** 2022-03-07 */
    TRANS_NUM: '筆',
    INCOME_TOTAL: '收入合計',
    OUTPUT_TOTAL: '支出合計',
    /** 2022-03-07 */
    /** 2022-03-08 */
    CONFIRM_REMOVE_REGISTERED_ACCOUNT: '確定是否刪除已登記的行內第三者帳戶',
    REGISTERED_INLINE_TIPS: [
      '1.服務時間： 24 小時',
      '2.轉賬至本行銀行帳戶或信用卡帳戶的交易指示即時處理（不接受轉賬至非登記第三者信用卡帳戶）。',
      '3.本行同行外幣轉賬功能只適用於同幣種轉賬。',
      '4.請按此查閱每日累積轉賬限額。如需設定交易限額至本行的最高交易限額，閣下必須親臨本行於香港任何分行申請。',
      '5.只接受以相同貨幣轉賬至信用卡帳戶。',
      '6.有關本行現金透支收費詳情，請參閱創興信用卡收費表及創興銀聯雙幣信用卡收費表。',
      '7.當交易指示已被執行後，畫面會顯示一個參考編號，以便您於日後作出查核。如畫面沒有顯示參考編號或您不確定有關交易是否已執行，請於重新進行交易前先查詢相關帳戶之結餘，以避免重複交易。',
    ],
    /** 2022-03-08 */
    /** 2022-03-10 */
    CREDIT_CURRENCY: '收款貨幣',
    CREDIT_CARD: '信用卡',
    EMAIL_NO_VALID: '郵箱地址不合法',
    PRESET_PAYEE_ACCOUNT: '預設收款賬戶',
    PRESET_PAYEE_BANK: '預設收款銀行',
    CHUANGXING_BANK: '創興銀行',
    CHUANGXING_BANK_CPY: '創興銀行有限公司',
    /** 2022-03-10 */
    /** 2022-03-11 */
    ADD_INFOS: '填寫新增信息',
    CONFIRM_ADD_INFOS: '確認新增信息',
    ADD_RESULT: '新增結果',
    UPDATE_INFOS: '填寫修改信息',
    CONFIRM_UPDATE_INFOS: '確認修改信息',
    UPDATE_RESULT: '修改結果',
    /** 2022-03-11 */
    /** 2022-03-23 */
    ACCT_ADDRESS: '國家/地區（收款人）',
    ACCT_NAME: '收款人名稱',
    PAY_ACCT_NAME: '賬戶/電話/電郵/FPS ID',
    /** 2022-03-23 */
    /** 2022-04-01 */
    AUTH_CENTER: '授權中心',
    /** 2022-04-01 */
    /** 2022-04-24 */
    HIGH_RISK_TRADE_TIP: '請通過創興香港企業手機銀行，使用流動保安認證在網上銀行進行的高風險交易',
    /** 2022-04-24 */
    /** 2022-04-28 */
    OVER_BALANCE_TIP: '使用透支額度可能會產生利息, 是否繼續交易？',
    ELEC_FEE: '電報費',
    /** 2022-04-28 */
    /** 2022-05-06 */
    BANK_PROXY_FEE: '銀行代理費',
    /** 2022-05-06 */
    /** 2022-05-07 */
    GOODS_TRADE: '公司客戶-貨物貿易',
    SERVICE_TRADE: '公司客戶-服務貿易',
    CAPITAL_TRANSFER: '公司客戶-資本項下跨境服務',
    CURRENT_ACCOUNT_TRANSCATION: '公司客戶-其他經常項目',
    CHARITY_DONATION: '公司客戶-慈善捐款',
    /** 2022-05-07 */
    /** 2022-05-10 */
    BANK_AND_ADDRESS: '國家+地址',
    /** 2022-05-16 */
    DEBIT_ACCT_DORMANT: '付款賬戶已被休眠',
    DEBIT_ACCT_FROZEN: '付款賬戶已被凍結',
    DEBIT_ACCT_CLOSED: '付款賬戶已被關閉',
    /** 2022-05-16 */
    /** 2022-05-17 */
    INCLUDE_SWIFT_ILEGAL: '包含SWIFT不支持的字符',
    /** 2022-05-17 */
    /** 2022-05-26 */
    CREDIT_ACCT_NOT_VALID: '收款賬戶不合法',
    /** 2022-05-26 */
    /** 2022-05-31 */
    RECENT_TRANSFER: '最近轉賬記錄',
    /** 2022-05-31 */
    /** 2022-06-01 */
    CHARGE_ACCT_DORMANT: '手續費扣款賬戶已休眠',
    CHARGE_ACCT_FROZEN: '手續費扣款賬戶已被凍結',
    CHARGE_ACCT_CLOSED: '手續費扣款賬戶已被停用',
    /** 2022-06-01 */
    /** 2022-06-07 */
    NOT_EDIT_TIP: '您還未修改信息',
    /** 2022-06-07 */
    /** 2022-06-21 */
    MODIFY_APPOINTMENT: '修改預約',
    DETAIL: '詳情',
    AUTH_NO: '授權編號',
    PAYER_NAME: '付款戶名',
    PAYER_BANK: '付款銀行/機構',
    PAYER_AMOUNT: '付款金額',
    /** 2022-06-21 */
    /** 2022-06-30 */
    DELETE_PAYEE: '確定刪除已選的收款人嗎？',
    /** 2022-06-30 */
    /** 2022-07-04 */
    PLEASE_INPUT: '請輸入%{input}',
    PLEASE_SELECT: '請選擇%{select}',
    PAYEE_ACCT_NAME: '收款賬戶名稱',
    SEARCH_NONE: '搜索無結果。',
    ACCT_REGISTED: '該收款資訊已被登記，請確認。',
    PAYEE_ACCT_NAME_ERROR: '收款賬戶名稱輸入錯誤，請重新輸入。',
    NO_REGIST_CREDIT_CARD: '不支援轉賬至未登記的信用卡賬戶。',
    ACCT_IS_REGIST: '該收款人已登記，請選擇已登記第三者賬戶進行轉賬。',
    NO_CHONGHING: '收款賬戶非創興銀行賬戶，請使用其他轉賬方式。',
    CREATED_PDF: '建立PDF檔案',
    EVERYDAY_LIMIT: '請按此查閱每日累積轉賬限額。如需設定交易限額至本行的最高交易限額，您必須親臨本行於香港任何分行申請。',
    EXCEED_AMOUNT: '該筆交易轉賬金額超過可用結餘，不能授權。',
    NOT_ACCEPT: '不接受',
    ACCEPT: '接受',
    PHONE_NUMBER: '電話號碼',
    COUNTRY_REGION_CODE: '國家/地區編號',
    PAYEE_BANK_NOT_FPS: '收款銀行/機構不支援轉數快轉賬，請確認。',
    CHARGE_ACCOUNT_NO_MONEY: '手續費扣款賬戶可用結餘不足以完成交易。',
    APP_CHARGE_ACCOUNT_NO_MONEY: '手續費扣款賬戶可用結餘不足，請在預設處理日期前補充足夠資金。',
    LOCAL_SEVER_TIME: '當前不在服務時間內。外幣轉賬（EUR/USD）服務時間為上午9時至下午5時（星期一至五），星期六、星期日及公眾假期包括本行所在地的公眾假期除外。',
    CHARGE_NO_AMOUNT_AUTH: '手續費扣款賬戶可用結餘不足，不能授權。',
    APP_ACCT_NO_AMOUNT: '費用扣款賬戶可用結餘不足，請在預設處理日期前補充足夠資金。',
    ACCT_NO_AMOUNT: '費用扣款賬戶可用結餘不足以完成交易。',
    PAYEE_NAME_SUP: '請將未完成輸入的收款人名稱繼續輸入在收款人地址欄中。如有地址，可在名稱後繼續輸入。',
    BANK_NAME_SUP: '請將未完成輸入的銀行名稱繼續輸入在銀行地址欄中。如有地址，可在名稱後繼續輸入',
    /** 2022-07-04 */
    /** 2022-07-05 */
    ACCT_IS_REGIST_COMFIRM: '該收款賬戶已經被登記，請確認。',
    ACCT_DID_NOT_REGIST: '收款賬戶為所在地企業賬戶，無須登記。',
    ACCT_NOT_INNER: '收款賬戶並非創興銀行賬戶，請登記本地跨行賬戶。',
    NOT_CHANGE: '您還未修改收款人資訊。',
    CONFIRM_DELETE: '確定刪除所選的本行已登記賬戶嗎？',
    MOBILE_IS_NOT_REGIST: '該%{type}未有登記轉數快。',
    IS_REGIST: '該收款人已經被登記，請確認。',
    PAYEE_UN_REGIST: '收款方未有登記轉數快。',
    IS_DELETE_REGIST_FPS: '確定刪除已登記的%{type}第三者賬戶嗎？',
    BANK_COUNTRY_REGION: '銀行國家/地區',
    PAYEE_ACCT_ERROR: '收款賬戶輸入錯誤，請重新輸入。',
    START_DATE: '開始日期',
    END_DATE: '結束日期',
    COST: '費用',
    NOT_CHANGE_DATA: '您還未修改預設處理日期。',
    CANCEL_APP: '您現正取消該筆預約交易，請確認。',
    CAN_NOT_CANCEL: '今天是預設處理日期，無法取消該筆交易。',
    CANT_NOT_CHANGE: '今天是預設處理日期，無法修改預設處理日期。',
    /** 2022-07-05 */
  },
  // 预约交易管理
  APPOINTTRACTION: {
    TRANS_TYPE: "交易類型",
    LOCAL_INTERBANK: '本地跨行',
    TELEGRAPHIC_TRANSFER: '全球匯款',
    FPS_TRANSFEP: '轉數快',
    CHATS_TRANSFER: '外幣轉賬(EUR/USD)',
    BATCH_TRANSFER: '批量轉賬',
    BATCH_PAYDAY: '批量發薪',
    BATCH_COLLECT: '自動轉賬收款',
    SUBMIT_TIME: '提交時間'
  },
  // 批量
  BRANCH_TRANSFER: {
    ONLINE_EDIT: '線上編輯',
    FILE_UPLOAD: '檔上載',
  }
}
